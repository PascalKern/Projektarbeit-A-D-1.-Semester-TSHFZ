/*
 * 
 */
package ch.packzeugs.semproject.business.person;

/**
 * The Class Coordinates keep informations about the coordinates like
 * eMail, Phone of a person object. 
 * <b>For this iteration not used nor implemented!<b> 
 */
public class Coordinates {

}
