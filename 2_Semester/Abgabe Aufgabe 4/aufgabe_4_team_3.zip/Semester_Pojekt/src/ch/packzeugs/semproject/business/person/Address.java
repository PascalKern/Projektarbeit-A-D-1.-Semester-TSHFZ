/* File description
 * 
 */
package ch.packzeugs.semproject.business.person;

/**
 * The Class Address keep informations about the address of a person
 * object. 
 * <b>For this iteration not used nor implemented!<b> 
 * 
 */
public class Address {

}
